package com.example.mycamera

import android.Manifest
import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView
import android.os.Bundle
import com.example.mycamera.R
import android.content.Intent
import android.graphics.Bitmap
import android.provider.MediaStore
import android.content.pm.PackageManager
import android.net.Uri
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity(), View.OnClickListener {
    var REQUEST_IMAGE_CAPTURE = 1
    var txt_path: TextView? = null
    var btn_open: Button? = null
    var readImageBtn: Button? = null
    var img_view: ImageView? = null
    var imageFileName: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        txt_path = findViewById<View>(R.id.txt_path) as TextView
        btn_open = findViewById<View>(R.id.btn_open) as Button
        btn_open!!.setOnClickListener(this)
       // readImageBtn = findViewById<View>(R.id.readImageBtn) as Button
        readImageBtn!!.setOnClickListener(this)
        img_view = findViewById<View>(R.id.img_view) as ImageView
        img_view!!.setOnClickListener(this)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_CAPTURE) {
            val photo = data!!.extras!!["data"] as Bitmap?

            // img_view.setImageBitmap(photo);
            //Uri tempUri = getImageUri(getApplicationContext(), photo);
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
            imageFileName = "JPEG_" + timeStamp + "_"
            val path =
                MediaStore.Images.Media.insertImage(contentResolver, photo, imageFileName, "sample")
            println(Uri.parse(path))
            img_view!!.setImageURI(Uri.parse(path))
        }
    }

    private fun imageCapture() {
        val openCamera = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(openCamera, REQUEST_IMAGE_CAPTURE)
    }

    override fun onClick(v: View) {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(
                    Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE
                ), 0
            )
        } else {
            imageCapture()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 0) {
            if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                imageCapture()
            }
        } else {
            Toast.makeText(this, "cant load", Toast.LENGTH_LONG).show()
        }
    }
}