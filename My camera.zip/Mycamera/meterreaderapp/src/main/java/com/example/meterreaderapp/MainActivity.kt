package com.example.meterreaderapp

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.IBinder
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.nabinbhandari.android.permissions.PermissionHandler
import com.nabinbhandari.android.permissions.Permissions
import com.example.meterreaderlib.IMRService
import com.example.meterreaderlib.IOnAnalogElectricMeterReadingCompletedListener
import com.example.meterreaderlib.IOnDigitalElectricMeterReadingCompletedListener
import kotlinx.android.synthetic.main.activity_main.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.logging.Level.INFO

class MainActivity : AppCompatActivity(),ServiceConnection, View.OnClickListener {
    private var IMAGE_PATH = "" // Change this to point to the right image
    private val isAnalog = true // Change this according to the meter type (analog or digital)
    private var REQUEST_IMAGE_CAPTURE=1
    var imageFileName: String? = null
    var openCamera: Button? = null


    private lateinit var service: IMRService
  /*  var readImageBtn: Button? = null
    var meterReading: TextView?=null
    var meterReadingAccuracy: TextView?=null
    var meterReadingStatus: TextView?=null
    var inferenceTime: TextView?=null*/

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        openCamera = findViewById<View>(R.id.openCamera) as Button
        openCamera!!.setOnClickListener(this)


        this.checkPermissions()

        readImageBtn.setOnClickListener {
            if (isAnalog) {
                readAnalogElectricMeter(IMAGE_PATH)
            } else {
                readDigitalElectricMeter(IMAGE_PATH)
            }
        }
    }

    private fun readDigitalElectricMeter(meterFilePath: String) {
        val startTime: Long = System.currentTimeMillis()
        service.readDigitalElectricMeterFromFile(meterFilePath, object : IOnDigitalElectricMeterReadingCompletedListener.Stub() {
            override fun onDigitalElectricMeterReadingCompleted(reading: String, status: Int, accuracy: Float) {
                val t =  (System.currentTimeMillis() - startTime)
                Log.d("MRSClient", "Reading time = $t ms")

                runOnUiThread {
                    Log.d("MRSClient", "reading = $reading\tstatus = $status\taccuracy = $accuracy")

                    meterReading.text = "Reading = $reading"
                    meterReadingStatus.text = "Status = $status"
                    meterReadingAccuracy.text = "Accuracy = $accuracy"
                    inferenceTime.text = "Time = $t ms"
                }
            }
        })
    }

    private fun readAnalogElectricMeter(meterFilePath: String) {
        val startTime: Long = System.currentTimeMillis()
        service.readAnalogElectricMeterFromFile(meterFilePath, object : IOnAnalogElectricMeterReadingCompletedListener.Stub() {
            override fun onAnalogElectricMeterReadingCompleted(reading: String, status: Int, accuracy: Float) {
                val t =  (System.currentTimeMillis() - startTime)
                Log.d("MRSClient", "Reading time = $t ms")

                runOnUiThread {
                    Log.d("MRSClient", "reading = $reading\tstatus = $status\taccuracy = $accuracy")

                    meterReading.text = "Reading = $reading"
                    meterReadingStatus.text = "Status = $status"
                    meterReadingAccuracy.text = "Accuracy = $accuracy"
                    inferenceTime.text = "Time = $t ms"
                }
            }
        })
    }

    override fun onStart() {
        super.onStart()
        bindService(
            Intent("com.olameter.meterreaderservice.MeterReaderService").setPackage("com.olameter.meterreaderservice"),
            this,
            BIND_AUTO_CREATE
        )
    }

    override fun onServiceConnected(name: ComponentName?, iBender: IBinder?) {
        service = IMRService.Stub.asInterface(iBender)

        Toast.makeText(
            this,
            "MeterReaderService Connected",
            Toast.LENGTH_LONG
        ).show()
    }

    override fun onServiceDisconnected(name: ComponentName?) {
        Toast.makeText(
            this,
            "MeterReaderService Disconnected",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun checkPermissions() {
        Permissions.check(
            this,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            null,
            object : PermissionHandler() {
                override fun onGranted() {}

                override fun onDenied(context: Context?, deniedPermissions: ArrayList<String>?) {
                    super.onDenied(context, deniedPermissions)

                    throw Error("Permission required: Read External Storage")
                }
            })
    }


    override fun onClick(v: View) {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(
                    Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE
                ), 0
            )
        } else {
            imageCapture()
        }
    }

    private fun imageCapture() {
        val openCamera = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(openCamera, REQUEST_IMAGE_CAPTURE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_CAPTURE) {
            val photo = data!!.extras!!["data"] as Bitmap?

            // img_view.setImageBitmap(photo);
            //Uri tempUri = getImageUri(getApplicationContext(), photo);
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
            imageFileName = "JPEG_" + timeStamp + "_"
            val path =
                MediaStore.Images.Media.insertImage(contentResolver, photo, imageFileName, "sample")
            println(Uri.parse(path))
            IMAGE_PATH=(Uri.parse(path)).toString()
            imgView!!.setImageURI(Uri.parse(path))
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 0) {
            if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                imageCapture()
            }
        } else {
            Toast.makeText(this, "cant load", Toast.LENGTH_LONG).show()
        }
    }

}
