package com.example.recieverapp;

import static android.content.Intent.ACTION_VIEW;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Parcel;
import android.os.Parcelable;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class MainActivity extends AppCompatActivity  {
TextView txt;
ArrayList arrayList;
    Uri returnUri;
    InputStream inputStream;
    Document doc ;
    String mime;
    HashMap<String,String> d;
    WebView webView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt = (TextView) findViewById(R.id.txt);
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);

        Intent intent = getIntent();
        returnUri = intent.getData();
        String mimeType = getContentResolver().getType(returnUri);

        String s = returnUri.toString();
        txt.setText(s);

        try {
            inputStream = getContentResolver().openInputStream(returnUri);
            txt.setText(inputStream.toString());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        DocumentBuilderFactory Dbf=DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = null;
        try {
            dBuilder = Dbf.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }

        try {
          //  File file=new File(String.valueOf(inputStream));
             doc = dBuilder.parse(inputStream);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        }

        doc.getDocumentElement().normalize();

        System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
        NodeList nList = doc.getElementsByTagName("supercars");
        System.out.println("----------------------------");

        for (int temp = 0; temp < nList.getLength(); temp++) {
            Node nNode = nList.item(temp);
            System.out.println("\nCurrent Element :" + nNode.getNodeName());
            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element eElement = (Element) nNode;
                System.out.println("Company : "
                        + eElement.getAttribute("company"));
                System.out.println("Car Name : "
                        + eElement.getElementsByTagName("carname")
                        .item(0).getTextContent());
                System.out.println("Company : "
                        + eElement.getAttribute("type"));
            }
        }

        final Activity activity = this;
        webView.setWebViewClient(new WebViewClient() {
            @SuppressWarnings("deprecation")
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Toast.makeText(activity, description, Toast.LENGTH_SHORT).show();
            }
            @TargetApi(android.os.Build.VERSION_CODES.M)
            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError rerr) {
                // Redirect to deprecated method, so you can use it in all SDK versions
                onReceivedError(view, rerr.getErrorCode(), rerr.getDescription().toString(), req.getUrl().toString());
            }
        });

        mime = getContentResolver().getType(returnUri);

        webView.getSettings().setJavaScriptEnabled(true);
//        webView.loadUrl(String.valueOf(returnUri));


        Intent intent1 = new Intent(ACTION_VIEW);
        intent1.setDataAndType(returnUri, "text/xml");
        startActivity(intent1);




















//        arrayList=(ArrayList)getIntent().getParcelableArrayListExtra("data");
//        txt.setText(" ");
//        for(int i=0;i<2;i++)
//        {
//            d=new HashMap<String,String>();
//            d= (HashMap<String, String>) arrayList.get(i);
//            for(int j=0;j<d.size();j++)
//            {
//                Object o=d.get("Name");
//               txt.setText((String)o);
//            }
//        }
    }

}


