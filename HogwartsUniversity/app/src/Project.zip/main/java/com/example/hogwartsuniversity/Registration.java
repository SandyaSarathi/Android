package com.example.hogwartsuniversity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


public class Registration extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {

    DatePickerDialog datePickerDialog;
    EditText txt_dob;
    EditText txt_date_joining;
    Spinner spinner_course,spinner_branch;
    ArrayAdapter arrayAdapter_course;

    String[] courses = {"B.E","B.Tech","B.Arch","M.E","M.Tech","MBA"};
    String[] branch = {"Computer Science and Engineering","Mechanical Engineering","Civil Engineering","Aeronautical Engineering","Electronics and Communication Engineering"
    ,"Electrical and Electronics Engineering","Information Technology","Human Resource Management","Finance","Marketing","Business Analytics"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        txt_dob=(EditText) findViewById(R.id.txt_dob);
        txt_dob.setOnClickListener(this);
        txt_date_joining=(EditText) findViewById(R.id.txt_date_joining);
        txt_date_joining.setOnClickListener(this);
        spinner_course=(Spinner) findViewById(R.id.spinner_course);
        spinner_course.setOnItemSelectedListener(this);
        arrayAdapter_course = new ArrayAdapter(this, android.R.layout.simple_spinner_item,courses);
        arrayAdapter_course.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_course.setAdapter(arrayAdapter_course);
        spinner_branch=(Spinner) findViewById(R.id.spinner_branch);
        spinner_branch.setOnItemSelectedListener(this);
        arrayAdapter_course = new ArrayAdapter(this, android.R.layout.simple_spinner_item,branch);
        arrayAdapter_course.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_branch.setAdapter(arrayAdapter_course);


    }

    @Override
    public void onClick(View v) {
        datePickerDialog = new DatePickerDialog(Registration.this, new DatePickerDialog.OnDateSetListener() {     // Displays DatePicker and can able to set the date to textfield
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                // Showing date selected from datePicker in Edit Text
                switch (v.getId())
                {
                    case R.id.txt_dob:
                        txt_dob.setText(String.valueOf(month+1)+"/"+String.valueOf(dayOfMonth)+"/"+String.valueOf(year));
                        setContentView(R.layout.activity_login_page);
                        //
                    case R.id.txt_date_joining:
                        txt_date_joining.setText(String.valueOf(month+1)+"/"+String.valueOf(dayOfMonth)+"/"+String.valueOf(year));

                    default:

                }

        }}, 2020, 0, 1);
        datePickerDialog.show();

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        Toast.makeText(getApplicationContext(),
                courses[position],
                Toast.LENGTH_LONG)
                .show();


    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}