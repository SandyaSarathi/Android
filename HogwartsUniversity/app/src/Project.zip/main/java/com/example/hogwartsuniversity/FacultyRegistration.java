package com.example.hogwartsuniversity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class FacultyRegistration extends AppCompatActivity implements View.OnClickListener {


    DatePickerDialog datePickerDialog;
    EditText txt_dob,txt_date_hired;
    Spinner spinner_type,spinner_teaching,spinner_department;
    String[] category={"Academic","Non Academic"};
    String[] academic = {"HOD","Professor","Assistant.Professor","Principal"};
    String[] non_academic={"Clerk","Lab Assistant","Librarian","Office Assistant","Cashier"};
    String[] department={"AERO","CSE","ECE","EEE","IT","CIVIL","MECH"};
    ArrayAdapter arrayAdapter,arrayAdapter_department;
    RelativeLayout relativeLayout;
    TextView txt;
    EditText txt_id,txt_name,txt_father,txt_mobile,txt_mail,txt_address,txt_expirience,txt_university,
            txt_degree,txt_passed_year,txt_percentage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faculty_registration);

        spinner_type=(Spinner) findViewById(R.id.spinner_type);

        arrayAdapter=new ArrayAdapter(this, android.R.layout.simple_spinner_item,category);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_type.setAdapter(arrayAdapter);

        spinner_teaching=(Spinner) findViewById(R.id.spinner_designation);

        spinner_department=(Spinner) findViewById(R.id.spinner_department);


        txt_dob = (EditText) findViewById(R.id.txt_dob);
        txt_dob.setOnClickListener(this);

        txt_date_hired = (EditText) findViewById(R.id.txt_hired_date);
        txt_date_hired.setOnClickListener(this);

        txt = (TextView) findViewById(R.id.test);

        relativeLayout=(RelativeLayout)findViewById(R.id.relative_layout);
        RelativeLayout.LayoutParams param = (RelativeLayout.LayoutParams) relativeLayout.getLayoutParams();

        txt_id=(EditText)findViewById(R.id.txt_id);
        txt_name=(EditText)findViewById(R.id.txt_name);
        txt_mobile=(EditText)findViewById(R.id.txt_mobile);
        txt_mail=(EditText)findViewById(R.id.txt_mail);
        txt_father=(EditText)findViewById(R.id.txt_lname);
        txt_address=(EditText)findViewById(R.id.txt_address);
        txt_university=(EditText)findViewById(R.id.txt_university);
        txt_degree=(EditText)findViewById(R.id.txt_degree);
        txt_percentage=(EditText)findViewById(R.id.txt_percentage);
        txt_expirience=(EditText)findViewById(R.id.txt_expirience);
        txt_passed_year=(EditText)findViewById(R.id.txt_passed_year);


        spinner_type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selected = parent.getItemAtPosition(position).toString();
                System.out.println(selected);
                switch (selected) {

                    case "Academic":
                        arrayAdapter = new ArrayAdapter(FacultyRegistration.this,android.R.layout.simple_spinner_item, academic);
                        arrayAdapter_department=new ArrayAdapter(FacultyRegistration.this,android.R.layout.simple_spinner_item, department);
                        txt.setVisibility(View.VISIBLE);
                        spinner_department.setVisibility(View.VISIBLE);
                        param.setMargins(0,1400,0,0);
                        relativeLayout.setLayoutParams(param);
                        break;
                    case "Non Academic":
                        arrayAdapter = new ArrayAdapter(FacultyRegistration.this, android.R.layout.simple_spinner_item, non_academic);
                        txt.setVisibility(View.GONE);
                        spinner_department.setVisibility(View.GONE);
                        param.setMargins(0,1300,0,0);
                        relativeLayout.setLayoutParams(param);
                        break;
                }
                arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinner_teaching.setAdapter(arrayAdapter);
                arrayAdapter_department.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinner_department.setAdapter(arrayAdapter_department);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.txt_dob:
                datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        txt_dob.setText(String.valueOf(month+1)+"/"+String.valueOf(dayOfMonth)+"/"+String.valueOf(year));

                    }
                },2020, 0, 1);
                datePickerDialog.show();
                break;
            case R.id.txt_hired_date:
                datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        txt_date_hired.setText(String.valueOf(month+1)+"/"+String.valueOf(dayOfMonth)+"/"+String.valueOf(year));
                    }
                },2020, 0, 1);
                datePickerDialog.show();
                break;
        }
    }

    public void validation(View view)
    {

        System.out.println(txt_id.getText().toString());
        //System.out.println();
        if(txt_id.getText().toString().isEmpty())
        {
            Intent i = new Intent(this,FacultyRegistrationEducation.class);
            startActivity(i);

            System.out.println(txt_id.getText().toString());
            Toast.makeText(this,"Enter Id",Toast.LENGTH_LONG).show();
        }
        else if(txt_name.getText().toString().isEmpty())
        {
            Intent i = new Intent(this,FacultyRegistrationPersonal.class);
            startActivity(i);
            Toast.makeText(this,"Enter Name",Toast.LENGTH_LONG).show();
        }
        else if(txt_father.getText().toString().isEmpty())
        {
            Intent i = new Intent(this,FacultyRegistrationContact.class);
            startActivity(i);
            Toast.makeText(this,"Enter Parent Name",Toast.LENGTH_LONG).show();
        }
        else if(txt_dob.getText().toString().isEmpty())
        {
            Intent i = new Intent(this,StudentRegistrationCourse.class);
            startActivity(i);
            Toast.makeText(this,"Enter Date Of Birth",Toast.LENGTH_LONG).show();
        }
        else if(txt_mobile.getText().toString().isEmpty())
        {
            Intent i = new Intent(this,FacultyRegistrationEducation.class);
            startActivity(i);
            Toast.makeText(this,"Enter mobile number",Toast.LENGTH_LONG).show();
        }
        else if(txt_mail.getText().toString().isEmpty())
        {
            Toast.makeText(this,"Enter email address",Toast.LENGTH_LONG).show();
        }
        else if(txt_address.getText().toString().isEmpty())
        {
            Toast.makeText(this,"Enter Address",Toast.LENGTH_LONG).show();
        }
        else if(txt_university.getText().toString().isEmpty())
        {
            Toast.makeText(this,"Enter university name",Toast.LENGTH_LONG).show();
        }
        else if(txt_degree.getText().toString().isEmpty())
        {
            Toast.makeText(this,"Enter degree obtained",Toast.LENGTH_LONG).show();
        }
        else if(txt_expirience.getText().toString().isEmpty())
        {
            Toast.makeText(this,"Enter expirience in years",Toast.LENGTH_LONG).show();
        }
        else if(txt_passed_year.getText().toString().isEmpty())
        {
            Toast.makeText(this,"Enter graduated year",Toast.LENGTH_LONG).show();
        }
        else
        {

        }

    }
}