package com.example.hogwartsuniversity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

public class DummyActivity extends AppCompatActivity implements View.OnClickListener {

    TextView txt_student_register,txt_faculty_register,txt_student_profile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dummy);

        txt_student_register = (TextView) findViewById(R.id.txt_student_register);
        txt_student_register.setOnClickListener(this);

        txt_faculty_register = (TextView) findViewById(R.id.txt_faculty_register);
        txt_faculty_register.setOnClickListener(this);

        txt_student_profile = (TextView) findViewById(R.id.txt_student_profile);
        txt_student_profile.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        switch(v.getId())
        {
            case R.id.txt_faculty_register:
                Intent i = new Intent(this,ProfilePage.class);
                startActivity(i);
                break;
            case R.id.txt_student_register:
                Intent i1 = new Intent(this,FacultyRegistrationPersonal.class);
                startActivity(i1);
                break;
            case R.id.txt_student_profile:
                Intent i2 = new Intent(this,StudentProfile.class);
                startActivity(i2);
                break;
        }

    }
}