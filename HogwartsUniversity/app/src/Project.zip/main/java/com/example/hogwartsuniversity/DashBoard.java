package com.example.hogwartsuniversity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;

import java.util.ArrayList;

public class DashBoard extends NavigationDrawer implements View.OnClickListener, AdapterView.OnItemClickListener {
    GridView gridView;
    DBHandler db;
    String strUser;
    TextView lbl_logout,lbl_user;
    DrawerLayout drawerLayout;
    DataClass dataClass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_dash_board);
        drawerLayout=(DrawerLayout)findViewById(R.id.drawer_layout);
        LayoutInflater inflater = (LayoutInflater) this
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View contentView = inflater.inflate(R.layout.activity_dash_board, null, false);
        drawerLayout.addView(contentView, 0);
        gridView = (GridView) findViewById(R.id.grid_view);
        gridView.setOnItemClickListener(this);

        lbl_logout = (TextView) findViewById(R.id.lbl_logout);
        lbl_logout.setOnClickListener(this);

        lbl_user = (TextView) findViewById(R.id.lbl_user);
        Intent i = getIntent();
        strUser=i.getStringExtra("userName");
        System.out.println(strUser);
        strUser= lbl_user.getText().toString()+" "+strUser;
        lbl_user.setText(strUser);

        ArrayList<DataClass> data = new ArrayList<>();
        db=new DBHandler(this);
        DataClass dataclass = (DataClass) getApplicationContext();

        data.add(new DataClass(Integer.parseInt(String.valueOf(db.countStudent())) ,R.drawable.student,"No.Of Students"));
        data.add(new DataClass(db.countTeachers(),R.drawable.teacher,"No.Of Teaching Staff"));
        data.add(new DataClass(db.countNonTeachers(),R.drawable.staff,"No.Of Non Teaching Staff"));
        data.add(new DataClass(db.countRecords(dataclass.getUser()),R.drawable.profile,"Registered Records"));

        GridAdapter adapterClass = new GridAdapter(this,data);
        gridView.setAdapter(adapterClass);
    }

    @Override
    public void onClick(View v) {
        Intent i = new Intent(this,LoginPage.class);
        startActivity(i);
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        if(position==3)
        {
            Intent i = new Intent(this,RegsiteredData.class);
            startActivity(i);
        }
    }
}