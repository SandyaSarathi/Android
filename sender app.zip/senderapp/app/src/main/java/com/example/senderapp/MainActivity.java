package com.example.senderapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;

@SuppressLint("ParcelCreator")
public class MainActivity extends AppCompatActivity implements View.OnClickListener,Parcelable {
Button SendBtn, Btn;
    ArrayList arrayList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SendBtn=(Button)findViewById(R.id.button1);
        SendBtn.setOnClickListener(this);
        Btn=(Button)findViewById(R.id.button2);
        Btn.setOnClickListener(this);


        //Creating a Dictionary
       HashMap<String, String> dict = new HashMap<String,String>();

        dict.put("Name","Xyz");
        dict.put("Age","17");
        dict.put("Gender","Female");

        HashMap<String, String> dict2 = new HashMap<String,String>();
        dict2.put("Name","ABC");
        dict2.put("Age","16");
        dict2.put("Gender","Male");

        //Assigning dictionary to Array
        arrayList=new ArrayList();
        arrayList.add( dict);
        arrayList.add( dict2);

        System.out.println(arrayList.get(0));

    }



    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button1:
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, arrayList);
                sendIntent.setType("text/plain");
                startActivity(sendIntent);

                break;

            case R.id.button2:
               Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.example.recieverapp");
              // Intent launchIntent=new Intent(this,SecondActivity.class);
                if (launchIntent != null) {
                    //launchIntent.putExtra("data",arrayList);
                    //launchIntent.putStringArrayListExtra("data",arrayList);
                   // launchIntent.putCharSequenceArrayListExtra("data",arrayList);
                   // launchIntent.putParcelableArrayListExtra("data", (ArrayList<? extends Parcelable>) arrayList);
                   // launchIntent.putExtra("data",arrayList);
                    launchIntent.putParcelableArrayListExtra("data",arrayList);
                  //  System.out.println(launchIntent.getStringExtra("data"));
                    // launchIntent.putExtra(MediaStore.EXTRA_OUTPUT,selectedImageUri);
                    startActivity(launchIntent);

                    break;
        }}
}

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {

    }
}