package com.example.senderapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Hashtable;

public class SecondActivity extends AppCompatActivity {

    TextView txt;
    ArrayList arrayList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        txt = (TextView) findViewById(R.id.txt);

        Intent intent = getIntent();
//        System.out.println(intent.getStringExtra("data"));
//        String sharedText = intent.getStringExtra("data");
        // arrayList=(ArrayList) getIntent().getStringArrayListExtra("data");
        arrayList=(ArrayList)getIntent().getSerializableExtra("data");
        txt.setText(" ");
        for(int i=0;i<arrayList.size();i++)
        {
            HashMap<String,String> d= (HashMap<String, String>) arrayList.get(i);
            //d=  arrayList.get(i);
            for(int j=0;j<d.size();j++)
            {
                Object o=d.get("Name");
                txt.setText((String)o);
            }
        }
    }
}


